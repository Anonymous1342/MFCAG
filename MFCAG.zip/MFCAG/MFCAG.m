function [F,alpha,obj] = MFCAG(X,C,B,gamma,tempF)

% Input:
%       - X: the data matrix of size nSmp * nFea * nView, where each row is a sample
%               point;
%       - C: the number of clusters;
%       - B: anchor graph;
%
% Output:
%       - F: the cluster assignment matrix;
%       - alpha: the view weight;
%       - obj: the objective funtion value;
%       - A: the optimized graph compatible across multiple views;


THRESHOLD = 1e-4;
Iter =10;

n_view = length(X);
n = size(X{1},1);

%% inilization
alpha(:,1) = ones(n_view,1)./n_view;
A = zeros(n,n);
for v = 1:n_view
    A = A+alpha(v).*B{v}*B{v}';
end

sumF=sum(tempF,1);
s = trace(tempF'*A*tempF)/(2*trace(sumF'*sumF));
%
for  it = 1:Iter

    %% fix alpha,s, update F
    M =s*ones(n,1)*ones(1,n) - A;
    [F,G,obj_F{it}] = SimplexQP_ALM(M,C,tempF);

    %% fix F,alpha, update s
    sumF=sum(F,1);
    s = trace(F'*A*F)/(2*trace(sumF'*sumF));


    %% fix F,s, update alpha
    for v = 1:n_view
        e(v,it) = trace((F'*B{v})*(B{v}'*F));
    end
    [alpha(:,it)] = EProjSimplex(s*e(:,it)/(2*gamma));

    A = zeros(n,n);
    for v = 1:n_view
        A = A+alpha(v,it).*B{v}*B{v}';
    end
    tempF = F;


    %% convergence

    obj(it) = s*trace(F'*A*F)-s^2*trace(sumF'*sumF) -gamma*sum(alpha(:,it).^2);


    if it >1
        if abs((obj(it)-obj(it-1))/obj(it)) < THRESHOLD

            break;

        end
    end

end

end