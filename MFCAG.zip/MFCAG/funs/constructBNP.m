

function B = constructBNP(X,centers,k)

n_view = length(X);
n = size(X{1},1);
m = size(centers{1},1);
B = cell(n_view,1);

for v = 1:n_view
    D = L2_distance_1(X{v}', centers{v}');
    [~, idx] = sort(D, 2);
    B{v} = zeros(n,m);
    for ii = 1:n
        id = idx(ii,1:k+1);
        di = D(ii, id);
        B{v}(ii,id) = (di(k+1)-di)/(k*di(k+1)-sum(di(1:k))+eps);
    end
    % sumB = sum(B{v});
    % sqrtB = sumB.^(-0.5);
    % B{v} = B{v}*(diag(sqrtB));
%     A=B{v}*B{v}'; 
end

end
