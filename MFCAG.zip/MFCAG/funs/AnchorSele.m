
function  centers = AnchorSele(X,anchor_rate,anchor_num,style,c)

%  - style:
%      - '1': Directly alternate sampling(default);
%      - '2': BKHK:
%      - '3': Kmeans; 
%      - '4': randomly sample

n_view = length(X);
n = size(X{1},1);
m = fix(n*anchor_rate);
% m=150;

XX = [];
for v = 1:n_view
    XX = [XX X{v}];
end
centers = cell(n_view,1);

if style == 1 % direct sample
    [~,ind,~] = graphgen_anchor(XX,m);
    for v = 1:n_view
        centers{v} = X{v}(ind, :);
    end
    
elseif style == 2 %BKHK
     [~,loccenters] = hKM(XX',[1:n],anchor_num,1);
     loccenters = loccenters';
     d0 = 0;
     for v = 1:n_view
         dv = size(X{v},2);
        centers{v} = loccenters(:,d0 + 1:d0 + dv);
        d0 = d0 + dv;
    end
    
elseif style == 3 % kmeans
    [~, ~, ~, ~, dis] = litekmeans(XX, m);
    [~,ind] = min(dis,[],1);
    ind = sort(ind,'ascend');
    for v = 1:n_view
        centers{v} = X{v}(ind, :);
    end   
    
elseif style == 4 % rand sample
    vec = randperm(n);
    ind = vec(1:m);
    for v = 1:n_view
        centers{v} = X{v}(ind, :);
    end
    
elseif style == 5 % kmeans sample
    for v = 1:n_view
        len(v) = size(X{v},2);
    end
    [~, Cen, ~, ~, ~] = litekmeans(XX, m);
    t1 = 1;
    for v=1:n_view
        t2 = t1+len(v)-1;
        centers{v} = Cen(:,t1:t2);
        t1 = t2+1;
    end
end