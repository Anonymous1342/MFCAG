function [F,G, obj] = SimplexQP_ALM(M,C,F)
% solve:
% min     x'Ax - b'x
% s.t.    x'1 = 1, x >= 0
% paras:
% mu    - mu > 0
% beta  - 1 < beta < 2

NITER = 100;
THRESHOLD = 1e-4;
mu=0.00001+rand();
rho = 1.1;
n = size(M,1);
sigma = ones(n,C);
G = F;

cnt = 0;

for iter = 1:NITER


    %% update F
    P = M*G;
    for i = 1:n
        temp(i,:) = (mu*G(i,:)- sigma(i,:) - P(i,:))/mu;
        F(i,:) = EProjSimplex(temp(i,:));
    end

    %% updata G
    G = (mu*F + sigma - M'*F)/mu;

    %% updata parameter: sigma, mu
    sigma = sigma + mu*(F - G);
    mu = rho*mu;

    %% convergence
    obj(iter)=norm(F - G,'fro').^2;%
    % obj1(iter) = trace(F'*D*F);
    if obj(iter) < THRESHOLD
        if cnt >= 2
            break;
        else
            cnt = cnt + 1;
        end
    else
        cnt = 0;
    end

end


end