
clear all
clc

addpath([pwd, '/funs']);
addpath([pwd, '/datasets']);



load TwoMoon.mat

rand('twister',5489)

C = length(unique(Y));

%
v = length(X);
n = length(Y);

% % % % % %%%normalization: 3source, bbcsport_2view, caltech101-7
% for i = 1 :v
%     for  j = 1:n
%         X{i}(j,:) = ( X{i}(j,:) - mean( X{i}(j,:) ) ) / std( X{i}(j,:) );
%     end
% end
%


%%% parameter setting
style = 1;
nearneighbor = 15;
anchor_rate = [0.2,0.3,0.4,0.5,0.6,0.7,0.8];
anchor_num = [4,5,6,7,8,9,10];
gamma=[0.01,0.1,1,10,100,1000];




% % %%%Initialization
XX = [];
for v = 1:length(X)
    XX = [XX X{v}];
end
[~,F] = fcm(XX,C);
tempF = F';


for i = 1:length(gamma)

    for j = 1:length(anchor_rate)

        %% single anchor graph construction
        centers = AnchorSele(X,anchor_rate(j),anchor_num,style,C);
        B = constructBNP(X,centers,nearneighbor);

        %% multi-view fuzzy clustering
        [F, alpha{j}, obj] = MFCAG(X,C,B,gamma(i),tempF);
        [~,Res] = max(F');
        [ACC(i,j), NMI(i,j), Purity(i,j), P(i,j), R(i,j), Fscore(i,j), RI(i,j)]  = ClusteringMeasure1(Y, Res');
    end

end
